/**
 * Creates buttons of random colors and allows user
 * to click on buttons to change its color and
 * the colors of the buttons around it. Goal
 * of game is to get all the buttons to turn black.
 * Once this happens, the background will change
 * from pink to white.
 *
 * @author Rhiannon McKinley
 */

package com.example.lightsout20;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import android.util.Log;
import com.google.api.Distribution;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ArrayList<Button> buttonList;
    ArrayList<String> colors;
    ArrayList<String> allBlack;
    ArrayList<LinearLayout> rows;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // create list to store current buttons
        buttonList = new ArrayList<Button>();
        colors = new ArrayList<String>();
        allBlack = new ArrayList<String>();
        rows = new ArrayList<LinearLayout>();


        // get id of layout to put buttons in
        LinearLayout r1 = findViewById(R.id.r1);
        rows.add(r1);
        LinearLayout r2 = findViewById(R.id.r2);
        rows.add(r2);
        LinearLayout r3 = findViewById(R.id.r3);
        rows.add(r3);
        LinearLayout r4 = findViewById(R.id.r4);
        rows.add(r4);
        LinearLayout r5 = findViewById(R.id.r5);
        rows.add(r5);

        // add buttons to layout and buttonList
        Button b1 = findViewById(R.id.b1);
        buttonList.add(b1);
        Button b2 = findViewById(R.id.b2);
        buttonList.add(b2);
        Button b3 = findViewById(R.id.b3);
        buttonList.add(b3);
        Button b4 = findViewById(R.id.b4);
        buttonList.add(b4);
        Button b5 = findViewById(R.id.b5);
        buttonList.add(b5);

        Button b6 = findViewById(R.id.b6);
        buttonList.add(b6);
        Button b7 = findViewById(R.id.b7);
        buttonList.add(b7);
        Button b8 = findViewById(R.id.b8);
        buttonList.add(b8);
        Button b9 = findViewById(R.id.b9);
        buttonList.add(b9);
        Button b10 = findViewById(R.id.b10);
        buttonList.add(b10);

        Button b11 = findViewById(R.id.b11);
        buttonList.add(b11);
        Button b12 = findViewById(R.id.b12);
        buttonList.add(b12);
        Button b13 = findViewById(R.id.b13);
        buttonList.add(b13);
        Button b14 = findViewById(R.id.b14);
        buttonList.add(b14);
        Button b15 = findViewById(R.id.b15);
        buttonList.add(b15);

        Button b16 = findViewById(R.id.b16);
        buttonList.add(b16);
        Button b17 = findViewById(R.id.b17);
        buttonList.add(b17);
        Button b18 = findViewById(R.id.b18);
        buttonList.add(b18);
        Button b19 = findViewById(R.id.b19);
        buttonList.add(b19);
        Button b20 = findViewById(R.id.b20);
        buttonList.add(b20);

        Button b21 = findViewById(R.id.b21);
        buttonList.add(b21);
        Button b22 = findViewById(R.id.b22);
        buttonList.add(b22);
        Button b23 = findViewById(R.id.b23);
        buttonList.add(b23);
        Button b24 = findViewById(R.id.b24);
        buttonList.add(b24);
        Button b25 = findViewById(R.id.b25);
        buttonList.add(b25);

        // set listener for reset button
        Button reset = findViewById(R.id.reset);
        reset.setOnClickListener(this);


        /* sets listeners for all buttons
           adds corresponding button color to color list
           makes all elements of allBlack list "black"
         */
        for (int i = 0; i < buttonList.size(); i++) {
            buttonList.get(i).setOnClickListener(this);
            colors.add(startColor(buttonList.get(i)));
            allBlack.add("black");
        }
    }


/**
 * startColor()
 * @author Rhiannon McKinley
 *
 * gives each button a random color at the start of the game and if the user presses "reset"
 *
 * @param button is the button that is being given a random color
 *
 * @return a String of either "black" or "white" that corresponds to the button color
 */

    public String startColor(Button button) {

        // create random int from 0 - 2
        Random rand = new Random();
        String currentColor;

        int randNum = rand.nextInt(2);

        // use random int to get random color for button
        if (randNum == 1) {
            currentColor = "black";
            applyColor(button, "black");

        } else {
            currentColor = "white";
            applyColor(button, "white");
        }
        return currentColor;
    }

    /**
     * applyColor()
     * @author Rhiannon McKinley
     *
     * sets the color of the button
     *
     * @param button is the button that is being set
     * @param color is either "black" or "white" that was returned from startColor
     *
     */

    public void applyColor(Button button, String color) {

        /**
         * External Citation
         * Date: 8 October 2023
         * Problem: Did not know how to set background color of button
         * Resource:
         * https://stackoverflow.com/questions/32671004/how-to-change-the-color-of-a-button
         * Solution: I used the example code from this post.
         */

        if (color.equals("black")) {
            button.setBackgroundColor(Color.BLACK);
        } else {
            button.setBackgroundColor(Color.WHITE);
        }
    }

    /**
     * changeColor()
     * @author Rhiannon McKinley
     *
     * changes button color from black to white or vise versa
     *
     * @param button is the button that is being changed
     * @param color is the orginal button color before it is changed
     *
     * @return a String of either "black" or "white" that corresponds to the new button color
     */

    public String changeColor(Button button, String color) {

        String currentColor;

        if (color.equals("black")) {
            applyColor(button, "white");
            currentColor = "white";
            return currentColor;
        } else {
            applyColor(button, "black");
            currentColor = "black";
            return currentColor;
        }
    }

    /**
     * onClick()
     * @author Rhiannon McKinley
     *
     * reset button: will rescramble the colors of the board
     * any other button: will change its color as well as those surrounding it
     *
     * @param v is the view where the buttons are
     *
     */
    @Override
    public void onClick(View v) {
        Button reset = findViewById(R.id.reset);

        // if user hits reset button
        if(reset.getId() == v.getId()) {
            // rescramble colors
            for(int i = 0; i < buttonList.size(); i++){
                colors.add(startColor(buttonList.get(i)));
            }
        }

        // if user hits grid button
            else {
            for (int i = 0; i < buttonList.size(); i++) {
                if (buttonList.get(i).getId() == v.getId()) {

                    /**
                     * External Citation
                     * Date: 8 October 2023
                     * Problem: Did not know how to make multiple cases have the same outcome in switch statement
                     * Resource:
                     * https://www.geeksforgeeks.org/switch-statement-in-java/
                     * Solution: I used the example code from this post.
                     */

                    /* colors change based on what button is hit
                       some buttons can change colors in all directions
                       while other colors cannot because they are on the edge
                       of the grid but all cases follow the same basic format
                       i is the index of the button in buttonList
                     */
                    switch (i) {

                        /**
                         * External Citation
                         * Date: 8 October 2023
                         * Problem: Did not know how to replace an element at a specfic index in an array list
                         * Resource:
                         * https://www.geeksforgeeks.org/how-to-replace-a-element-in-java-arraylist/
                         * Solution: I used the example code from this post.
                         */
                        /*
                            colors are changed based on the index value
                            the colors array list gets updated accordinally
                         */
                        case 0:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            break;

                        case 1:
                        case 2:
                        case 3:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            break;

                        case 4:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            break;

                        case 9:
                        case 14:
                        case 19:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));
                            break;

                        case 5:
                        case 10:
                        case 15:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));

                            break;


                        case 20:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));
                            break;

                        case 21:
                        case 22:
                        case 23:

                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));
                            break;

                        case 24:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));
                            break;

                        default:
                            colors.set(i, changeColor(buttonList.get(i), colors.get(i)));
                            colors.set(i + 1, changeColor(buttonList.get(i + 1), colors.get(i + 1)));
                            colors.set(i - 1, changeColor(buttonList.get(i - 1), colors.get(i - 1)));
                            colors.set(i + 5, changeColor(buttonList.get(i + 5), colors.get(i + 5)));
                            colors.set(i - 5, changeColor(buttonList.get(i - 5), colors.get(i - 5)));
                    }
                }
            }
        }

        /**
         * External Citation
         * Date: 8 October 2023
         * Problem: Did not know how to check if all buttons were black
         * Resource:
         * https://www.geeksforgeeks.org/comparing-two-arraylist-in-java/
         * Solution: I made another array list that was all black so I could compare the two
         */

        // if all buttons are black
        if(colors.equals(allBlack)) {
            LinearLayout background = findViewById(R.id.background);
            LinearLayout buttonBackground = findViewById(R.id.buttonLayout);
            // set background to white
            background.setBackgroundColor(Color.WHITE);
            buttonBackground.setBackgroundColor(Color.WHITE);
        }
    }
}


